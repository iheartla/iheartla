C++ support code for the code that I❤️LA generates (https://github.com/iheartla/iheartla)

Code with meshes or derivatives includes headers from include/: put it on the
include path (-Iiheartla-cpp/include). With meshes, also compile and link the
sources in src/. Derivatives need autodiff (https://github.com/autodiff/autodiff),
which needs Eigen 3.4.
